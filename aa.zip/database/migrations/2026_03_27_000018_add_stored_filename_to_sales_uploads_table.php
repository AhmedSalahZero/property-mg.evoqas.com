<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('sales_uploads', function (Blueprint $table) {
            $table->string('stored_filename')->nullable()->after('original_filename');
        });
    }

    public function down(): void
    {
        Schema::table('sales_uploads', function (Blueprint $table) {
            $table->dropColumn('stored_filename');
        });
    }
};